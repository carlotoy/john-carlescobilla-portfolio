<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_name = $_POST['customer_name'];
    $appointment_date = $_POST['appointment_date'];
    $gown_types = $_POST['gown_types'];
    $gown_quantities = $_POST['gown_quantities'];
    $gown_prices = $_POST['gown_prices'];
    
    $total_gowns = array_sum($gown_quantities);
    $total_price = 0;
    
    $summary = '<div class="space-y-2">';
    $summary .= '<p><span class="font-semibold">Customer Name:</span> ' . $customer_name . '</p>';
    $summary .= '<p><span class="font-semibold">Appointment Date:</span> ' . $appointment_date . '</p>';
    $summary .= '<p class="font-semibold">Gowns Rented:</p>';
    $summary .= '<ul class="list-disc pl-5">';
    foreach ($gown_types as $index => $gown) {
        $line_total = $gown_quantities[$index] * $gown_prices[$index];
        $total_price += $line_total;
        $summary .= '<li>' . $gown . ' - ' . $gown_quantities[$index] . ' pcs x ₱' . number_format($gown_prices[$index], 2) . ' = ₱' . number_format($line_total, 2) . '</li>';
    }
    $summary .= '</ul>';
    $summary .= '<p class="mt-4"><span class="font-semibold">Total Gowns Rented:</span> ' . $total_gowns . '</p>';
    $summary .= '<p><span class="font-semibold">Total Price:</span> ₱' . number_format($total_price, 2) . '</p>';
    $summary .= '</div>';
    
    // Set session variable to show modal
    session_start();
    $_SESSION['show_modal'] = true;
    $_SESSION['modal_content'] = $summary;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gown Rental Appointment</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen py-12">
    <!-- Back button -->
    <div class="max-w-2xl mx-auto mb-4">
        <a href="index.php" class="inline-block bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">
            Back to Home
        </a>
    </div>

    <!-- Modal -->
    <?php if(isset($_SESSION['show_modal']) && $_SESSION['show_modal']): ?>
    <div id="appointmentModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
        <div class="relative mx-auto p-8 bg-white w-full max-w-2xl rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-4">Appointment</h2>
            <?php  
                echo $_SESSION['modal_content'];
                // Clear session variables
                unset($_SESSION['show_modal']);
                unset($_SESSION['modal_content']);
            ?>
            <div class="mt-6 flex justify-end">
                <button onclick="closeModal()" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                    Close
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8">
        <h2 class="text-3xl font-bold text-center mb-8 text-gray-800">Gown Rental Appointment</h2>
        <form method="post" action="" class="space-y-6">
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2">Customer Name:</label>
                <input type="text" name="customer_name" required 
                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2">Appointment Date:</label>
                <input type="date" name="appointment_date" required
                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
            </div>
            
            <div id="gownEntries">
                <label class="block text-gray-700 text-sm font-bold mb-2">Gowns:</label>
                <div class="gown-entry flex space-x-4 mb-4">
                    <select name="gown_types[]" class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="Wedding Gown">Wedding Gown - ₱3000</option>
                        <option value="Evening Gown">Evening Gown - ₱2000</option>
                        <option value="Ball Gown">Ball Gown - ₱2500</option>
                    </select>
                    <input type="number" name="gown_quantities[]" min="1" required
                        class="w-24 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="Qty">
                    <input type="hidden" name="gown_prices[]" value="3000">
                </div>
            </div>
            
            <button type="button" onclick="addGownEntry()" 
                class="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600">
                Add Another Gown
            </button>
            
            <button type="submit" 
                class="w-full bg-indigo-600 text-white font-bold py-3 px-4 rounded-md hover:bg-indigo-700 transition duration-200">
                Submit Appointment
            </button>
        </form>
    </div>

    <script>
        function closeModal() {
            document.getElementById('appointmentModal').style.display = 'none';
        }

        function addGownEntry() {
            const container = document.getElementById('gownEntries');
            const newEntry = document.createElement('div');
            newEntry.className = 'gown-entry flex space-x-4 mb-4';
            newEntry.innerHTML = `
                <select name="gown_types[]" class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" onchange="updatePrice(this)">
                    <option value="Wedding Gown">Wedding Gown - ₱3000</option>
                    <option value="Evening Gown">Evening Gown - ₱2000</option>
                    <option value="Ball Gown">Ball Gown - ₱2500</option>
                </select>
                <input type="number" name="gown_quantities[]" min="1" required
                    class="w-24 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Qty">
                <input type="hidden" name="gown_prices[]" value="3000">
                <button type="button" onclick="removeGownEntry(this)" 
                    class="bg-red-500 text-white px-3 py-2 rounded-md hover:bg-red-600">
                    Remove
                </button>
            `;
            container.appendChild(newEntry);
        }

        function removeGownEntry(button) {
            button.parentElement.remove();
        }

        function updatePrice(select) {
            const priceInput = select.parentElement.querySelector('input[name="gown_prices[]"]');
            switch(select.value) {
                case 'Wedding Gown':
                    priceInput.value = '3000';
                    break;
                case 'Evening Gown':
                    priceInput.value = '2000';
                    break;
                case 'Ball Gown':
                    priceInput.value = '2500';
                    break;
            }
        }

        // Add price update handler to initial select
        document.querySelector('select[name="gown_types[]"]').addEventListener('change', function() {
            updatePrice(this);
        });
    </script>
</body>
</html>

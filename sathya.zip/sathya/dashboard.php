<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

// Database connection
$db = new PDO("mysql:host=localhost;dbname=gown_rental", "username", "password");

// Get rental statistics
$stats = $db->query("SELECT 
    COUNT(*) as total_rentals,
    COUNT(CASE WHEN status = 'active' THEN 1 END) as active_rentals,
    COUNT(CASE WHEN status = 'overdue' THEN 1 END) as overdue_rentals
    FROM rentals")->fetch();

// Get recent rentals
$recentRentals = $db->query("SELECT r.*, c.name as customer_name, g.name as gown_name 
    FROM rentals r 
    JOIN customers c ON r.customer_id = c.id
    JOIN gowns g ON r.gown_id = g.id 
    ORDER BY r.rental_date DESC LIMIT 5")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - S&V Gown Rental</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" type="image/x-icon" href="favicon.ico">
</head>
<body class="bg-gray-100">
    <nav class="bg-gray-900 text-white px-6 py-4">
        <div class="flex justify-between items-center">
            <div class="flex items-center space-x-4">
                <img src="img/logo.png" alt="S&V Gown Rental" class="h-8">
                <h1 class="text-xl font-semibold">Admin Dashboard</h1>
            </div>
            <div class="flex items-center space-x-4">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout.php" class="bg-red-500 px-4 py-2 rounded hover:bg-red-600">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-6 py-8">
        <!-- Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-gray-500 text-sm font-medium">Total Rentals</h3>
                <p class="text-3xl font-bold"><?php echo $stats['total_rentals']; ?></p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-gray-500 text-sm font-medium">Active Rentals</h3>
                <p class="text-3xl font-bold text-green-600"><?php echo $stats['active_rentals']; ?></p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-gray-500 text-sm font-medium">Overdue Rentals</h3>
                <p class="text-3xl font-bold text-red-600"><?php echo $stats['overdue_rentals']; ?></p>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <a href="new-rental.php" class="bg-blue-500 text-white rounded-lg p-4 text-center hover:bg-blue-600">
                New Rental
            </a>
            <a href="manage-gowns.php" class="bg-purple-500 text-white rounded-lg p-4 text-center hover:bg-purple-600">
                Manage Gowns
            </a>
            <a href="customers.php" class="bg-green-500 text-white rounded-lg p-4 text-center hover:bg-green-600">
                Customer List
            </a>
            <a href="reports.php" class="bg-yellow-500 text-white rounded-lg p-4 text-center hover:bg-yellow-600">
                Generate Reports
            </a>
        </div>

        <!-- Recent Rentals -->
        <div class="bg-white rounded-lg shadow">
            <div class="p-6 border-b">
                <h2 class="text-xl font-semibold">Recent Rentals</h2>
            </div>
            <div class="p-6">
                <table class="w-full">
                    <thead>
                        <tr class="text-left">
                            <th class="pb-4">Customer</th>
                            <th class="pb-4">Gown</th>
                            <th class="pb-4">Rental Date</th>
                            <th class="pb-4">Status</th>
                            <th class="pb-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentRentals as $rental): ?>
                        <tr class="border-t">
                            <td class="py-4"><?php echo htmlspecialchars($rental['customer_name']); ?></td>
                            <td class="py-4"><?php echo htmlspecialchars($rental['gown_name']); ?></td>
                            <td class="py-4"><?php echo date('M d, Y', strtotime($rental['rental_date'])); ?></td>
                            <td class="py-4">
                                <span class="px-2 py-1 rounded text-sm <?php echo $rental['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                    <?php echo ucfirst($rental['status']); ?>
                                </span>
                            </td>
                            <td class="py-4">
                                <a href="view-rental.php?id=<?php echo $rental['id']; ?>" class="text-blue-500 hover:text-blue-700">View Details</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>

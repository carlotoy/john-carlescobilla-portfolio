<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']); 
    $password = $_POST['password'];

    // Database connection
    $db = new PDO("mysql:host=localhost;dbname=gown_rental", "username", "password");
    
    // Prepare statement to prevent SQL injection
    $stmt = $db->prepare("SELECT id, username, password_hash FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['loggedin'] = true;
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        
        // Set last login timestamp
        $updateStmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $updateStmt->execute([$user['id']]);
        
        // Regenerate session ID to prevent session fixation
        session_regenerate_id(true);
        
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid username or password";
        // Log failed attempt
        error_log("Failed login attempt for username: " . $username);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Admin Login - S&V Gown Rental</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" type="image/x-icon" href="favicon.ico">
</head>
<body class="bg-gradient-to-r from-gray-100 to-gray-200">
    <!-- Sign Up Modal -->
    <div id="signupModal" class="fixed z-10 inset-0 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
            <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg w-full">
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mt-3 text-center sm:mt-0 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4" id="modal-title">
                                Create New Account
                            </h3>
                            <div class="mt-2">
                                <form id="signupForm" method="POST" action="process-signup.php" class="space-y-4">
                                    <div>
                                        <label for="newUsername" class="block text-sm font-medium text-gray-700">Username</label>
                                        <input type="text" name="newUsername" id="newUsername" required 
                                               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-1 focus:ring-gray-400 focus:border-gray-400">
                                    </div>
                                    <div>
                                        <label for="newPassword" class="block text-sm font-medium text-gray-700">Password</label>
                                        <input type="password" name="newPassword" id="newPassword" required 
                                               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-1 focus:ring-gray-400 focus:border-gray-400">
                                    </div>
                                    <div>
                                        <label for="confirmPassword" class="block text-sm font-medium text-gray-700">Confirm Password</label>
                                        <input type="password" name="confirmPassword" id="confirmPassword" required 
                                               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-1 focus:ring-gray-400 focus:border-gray-400">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" form="signupForm" 
                            class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-gray-900 text-base font-medium text-white hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm">
                        Sign Up
                    </button>
                    <button type="button" onclick="closeSignupModal()" 
                            class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="min-h-screen flex items-center justify-center px-4">
        <div class="max-w-4xl w-full bg-white rounded-lg overflow-hidden shadow-lg">
            <div class="flex flex-col md:flex-row">
                <!-- Left side with logo on gray background -->
                <div class="w-full md:w-1/2 bg-gray-50 p-8 md:p-12 flex items-center justify-center">
                    <img src="img/logo.png" alt="S&V Gown Rental" class="w-48 md:w-64">
                </div>
                
                <!-- Right side with login form -->
                <div class="w-full md:w-1/2 p-8 md:p-12">
                    <div class="mb-6 md:mb-8">
                        <h2 class="text-xl md:text-2xl font-normal text-gray-800 mb-2 md:mb-3">S&V Gown Rental</h2>
                        <p class="text-gray-600 text-sm">A lightweight and modular system for managing gown rentals.</p>
                    </div>

                    <?php if (isset($error)): ?>
                        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded" role="alert">
                            <p class="font-medium">Authentication Error</p>
                            <p><?php echo htmlspecialchars($error); ?></p>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="space-y-4 md:space-y-6">
                        <div>
                            <label for="username" class="block text-gray-700 text-sm mb-2">Username</label>
                            <input type="text" id="username" name="username" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400"
                                   placeholder="Enter your username"
                                   autocomplete="username">
                        </div>

                        <div>
                            <label for="password" class="block text-gray-700 text-sm mb-2">Password</label>
                            <input type="password" id="password" name="password" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400"
                                   placeholder="Enter your password"
                                   autocomplete="current-password">
                        </div>

                        <button type="submit" 
                                class="w-full bg-gray-900 text-white py-2.5 px-4 rounded-md hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-200">
                            Login
                        </button>
                    </form>

                    <div class="mt-6 text-center text-sm">
                        <p class="text-gray-600">Don't have an account? <button onclick="openSignupModal()" class="text-blue-500 hover:text-blue-700 font-medium">Sign up</button></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function openSignupModal() {
            document.getElementById('signupModal').classList.remove('hidden');
        }

        function closeSignupModal() {
            document.getElementById('signupModal').classList.add('hidden');
        }
    </script>
</body>
</html>

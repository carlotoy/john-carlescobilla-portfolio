<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wedding Collection - S&V Gown Rental</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="font-sans">
    <nav class="bg-white shadow-lg">
        <div class="max-w-6xl mx-auto px-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center items-start justify-start py-2">
                    <img src="img/logo.png" alt="Logo" class="h-10 w-10">
                    <span class="text-gray-700 font-bold text-xl">S&V Gown Rental</span>
                </div>
                <div class="flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-indigo-600 font-medium transition-colors duration-200">
                        Home
                    </a>
                    <div class="relative group">
                        <button class="text-gray-700 hover:text-indigo-600 font-medium transition-colors duration-200 flex items-center">
                            Gown
                            <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                        <div class="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                            <a href="wedding-collection.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600">Wedding Collection</a>
                            <a href="evening-collection.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600">Evening Collection</a>
                            <a href="special-events.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600">Tuxedo Collection</a>
                        </div>
                    </div>
                    <div class="relative group">
                        <button class="text-gray-700 hover:text-indigo-600 font-medium transition-colors duration-200 flex items-center">
                            Pricing
                            <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                        <div class="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                            <a href="rental-packages.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600">Rental Packages</a>
                            <a href="seasonal-offers.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600">Seasonal Offers</a>
                            <a href="custom-pricing.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600">Custom Pricing</a>
                        </div>
                    </div>
                    <a href="booking.php" class="text-gray-700 hover:text-indigo-600 font-medium transition-colors duration-200">
                        Book Now
                    </a>
                    <a href="contact.php" class="text-gray-700 hover:text-indigo-600 font-medium transition-colors duration-200">
                        Contact
                    </a>
                </div>
                <div class="flex justify-end">
                    <button onclick="window.location.href='login.php'" class="text-gray-700 hover:text-indigo-600 font-medium transition-colors duration-200 border border-indigo-500 rounded-md px-4 py-2 bg-indigo-500 hover:bg-indigo-100 text-white">
                        Login
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="relative h-[500px]">
        <div class="absolute inset-0">
            <div class="absolute inset-0 bg-black opacity-50"></div>
        </div>
        <div class="relative max-w-7xl mx-auto px-4 h-full flex items-center">
            <div class="text-white">
                <h1 class="text-5xl font-bold mb-4">Wedding Collection</h1>
                <p class="text-xl mb-8">Find your perfect wedding dress for your special day</p>
                <a href="#collection" class="bg-white text-indigo-600 px-8 py-4 rounded-lg font-bold hover:bg-indigo-50 transition-colors">
                    View Collection
                </a>
            </div>
        </div>
    </section>

    <!-- Collection Grid -->
    <section id="collection" class="py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php
                $wedding_dresses = [
                    [
                        'name' => 'Wedding Gown 1',
                        'price' => '₱1,000',
                        'image' => 'img/wedding1.jpg'
                    ],
                    [
                        'name' => 'Wedding Gown 2',
                        'price' => '₱1,000',
                        'image' => 'img/wedding2.jpg'
                    ],
                    [
                        'name' => 'Wedding Gown 3',
                        'price' => '₱1,000',
                        'image' => 'img/wedding3.jpg'
                    ],
                    [
                        'name' => 'Wedding Gown 4',
                        'price' => '₱1,000',
                        'image' => 'img/wedding4.jpg'
                    ],
                    [
                        'name' => 'Wedding Gown 5',
                        'price' => '₱1,000',
                        'image' => 'img/wedding5.jpg'
                    ],
                    [
                        'name' => 'Wedding Gown 6',
                        'price' => '₱1,000',
                        'image' => 'img/wedding6.jpg'
                    ],
                ];

                foreach ($wedding_dresses as $dress) {
                    echo '<div class="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">';
                    echo '<img src="' . $dress['image'] . '" alt="' . $dress['name'] . '" class="w-full h-96 object-cover">';
                    echo '<div class="p-6">';
                    echo '<h3 class="text-xl font-bold mb-2">' . $dress['name'] . '</h3>';
                    echo '<p class="text-gray-600 mb-4">Rental starts from ' . $dress['price'] . '</p>';
                    echo '<a href="booking.php" class="inline-block bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors">Book Now</a>';
                    echo '</div>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Booking Process -->
    <section class="py-20">
        <div class="max-w-7xl mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12">How to Book Your Dream Dress</h2>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div class="text-center">
                    <div class="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">1</div>
                    <h3 class="font-bold mb-2">Browse Collection</h3>
                    <p class="text-gray-600">Explore our curated selection of wedding dresses</p>
                </div>
                <div class="text-center">
                    <div class="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">2</div>
                    <h3 class="font-bold mb-2">Book Appointment</h3>
                    <p class="text-gray-600">Schedule a fitting session</p>
                </div>
                <div class="text-center">
                    <div class="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">3</div>
                    <h3 class="font-bold mb-2">Try & Select</h3>
                    <p class="text-gray-600">Find your perfect fit</p>
                </div>
                <div class="text-center">
                    <div class="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">4</div>
                    <h3 class="font-bold mb-2">Confirm Booking</h3>
                    <p class="text-gray-600">Secure your dress for the big day</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12">
        <div class="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
                <h3 class="text-xl font-bold mb-4">S&V Gown Rental</h3>
                <p class="text-gray-400">Making your special moments unforgettable with our premium gown collection.</p>
            </div>
            <div>
                <h4 class="font-bold mb-4">Quick Links</h4>
                <ul class="space-y-2">
                    <li><a href="about.php" class="text-gray-400 hover:text-white">About Us</a></li>
                    <li><a href="services.php" class="text-gray-400 hover:text-white">Services</a></li>
                    <li><a href="gallery.php" class="text-gray-400 hover:text-white">Gowns</a></li>
                    <li><a href="contact.php" class="text-gray-400 hover:text-white">Contact</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-bold mb-4">Contact Info</h4>
                <ul class="space-y-2 text-gray-400">
                    <li>Zone 8 Ordnance, Camp Evangelista, Patag</li>
                    <li>Cagayan de Oro City, Philippines</li>
                    <li>Phone: 0975 320 6018</li>
                    <li>Email: sali.kilat.coc@phinmaed.com</li>
                </ul>
            </div>
            <div>
                <h4 class="font-bold mb-4">Follow Us</h4>
                <div class="flex space-x-4">
                    <a href="https://www.facebook.com/profile.php?id=100090762784236" class="text-gray-400 hover:text-white">
                        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white">
                        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                    </a>
                </div>
            </div>
        </div>
        <div class="max-w-7xl mx-auto px-4 mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
            <p>&copy; <?php echo date('Y'); ?> S&V Gown Rental. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
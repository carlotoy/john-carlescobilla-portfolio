<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ball Collection - S&V Gown Rental</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="font-sans">
    <nav class="bg-white shadow-lg">
        <div class="max-w-6xl mx-auto px-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center items-start justify-start py-2">
                    <img src="img/logo.png" alt="Logo" class="h-10 w-10">
                    <span class="text-gray-700 font-bold text-xl">S&V Gown Rental</span>
                </div>
                <div class="flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-indigo-600 font-medium transition-colors duration-200">
                        Home
                    </a>
                    <div class="relative group">
                        <button class="text-gray-700 hover:text-indigo-600 font-medium transition-colors duration-200 flex items-center">
                            Gown
                            <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                        <div class="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                            <a href="wedding-collection.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600">Wedding Collection</a>
                            <a href="ball-collection.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600">Ball Collection</a>
                            <a href="special-events.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600">Raffles Collection</a>
                            <a href="special-events.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600">Pageant Collection</a>
                        </div>
                    </div>
                    <a href="booking.php" class="text-gray-700 hover:text-indigo-600 font-medium transition-colors duration-200">
                        Book Now
                    </a>
                    <a href="contact.php" class="text-gray-700 hover:text-indigo-600 font-medium transition-colors duration-200">
                        Contact
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="relative h-96">
        <div class="absolute inset-0">
            <div class="absolute inset-0 bg-black opacity-50"></div>
        </div>
        <div class="relative max-w-7xl mx-auto px-4 h-full flex items-center">
            <div class="text-white">
                <h1 class="text-4xl md:text-5xl font-bold mb-4">Ball Collection</h1>
                <p class="text-xl mb-8">Discover our stunning collection of ball gowns for your special occasion</p>
            </div>
        </div>
    </section>

    <!-- Collection Grid -->
    <section class="py-16">
        <div class="max-w-7xl mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php
                $gowns = [
                    [
                        'image' => 'img/ball1.jpg',
                        'name' => 'Classic Ball Gown',
                        'description' => 'Elegant ball gown with detailed embellishments',
                        'price' => '₱2,500'
                    ],
                    [
                        'image' => 'img/ball2.jpg',
                        'name' => 'Princess Ball Gown',
                        'description' => 'Stunning princess-style ball gown',
                        'price' => '₱2,500'
                    ],
                    [
                        'image' => 'img/ball3.jpg',
                        'name' => 'Modern Ball Gown',
                        'description' => 'Contemporary design with classic elements',
                        'price' => '₱2,500'
                    ],
                    [
                        'image' => 'img/ball4.jpg',
                        'name' => 'Luxury Ball Gown',
                        'description' => 'Premium ball gown with exquisite details',
                        'price' => '₱2,500'
                    ],
                    [
                        'image' => 'img/ball5.jpg',
                        'name' => 'Vintage Ball Gown',
                        'description' => 'Timeless vintage-inspired design',
                        'price' => '₱2,500'
                    ],
                    [
                        'image' => 'img/ball6.jpg',
                        'name' => 'Royal Ball Gown',
                        'description' => 'Majestic ball gown fit for royalty',
                        'price' => '₱2,500'
                    ]
                ];

                foreach ($gowns as $gown) {
                    echo '<div class="bg-white rounded-lg shadow-lg overflow-hidden">';
                    echo '<img src="' . $gown['image'] . '" alt="' . $gown['name'] . '" class="w-full h-80 object-cover">';
                    echo '<div class="p-6">';
                    echo '<h3 class="text-xl font-bold mb-2">' . $gown['name'] . '</h3>';
                    echo '<p class="text-gray-600 mb-4">' . $gown['description'] . '</p>';
                    echo '<div class="flex justify-between items-center">';
                    echo '<span class="text-xl font-bold text-indigo-600">' . $gown['price'] . '</span>';
                    echo '<a href="booking.php" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Book Now</a>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12">
        <div class="max-w-7xl mx-auto px-4">
            <div class="text-center">
                <p>&copy; <?php echo date('Y'); ?> S&V Gown Rental. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
